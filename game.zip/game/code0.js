gdjs._27161_38988_20171_38754Code = {};
gdjs._27161_38988_20171_38754Code.localVariables = [];
gdjs._27161_38988_20171_38754Code.idToCallbackMap = new Map();
gdjs._27161_38988_20171_38754Code.GDNewPanelSprite2Objects1= [];
gdjs._27161_38988_20171_38754Code.GDNewPanelSprite2Objects2= [];
gdjs._27161_38988_20171_38754Code.GD_9538283_9522987_9536938_9525138_9525991_9526412Objects1= [];
gdjs._27161_38988_20171_38754Code.GD_9538283_9522987_9536938_9525138_9525991_9526412Objects2= [];
gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects1= [];
gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects2= [];
gdjs._27161_38988_20171_38754Code.GDNewPanelSpriteObjects1= [];
gdjs._27161_38988_20171_38754Code.GDNewPanelSpriteObjects2= [];
gdjs._27161_38988_20171_38754Code.GD_9536984_9521934Objects1= [];
gdjs._27161_38988_20171_38754Code.GD_9536984_9521934Objects2= [];
gdjs._27161_38988_20171_38754Code.GD_9524863_9525033_9522602Objects1= [];
gdjs._27161_38988_20171_38754Code.GD_9524863_9525033_9522602Objects2= [];


gdjs._27161_38988_20171_38754Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("遊戲開始鍵"), gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects1.length;i<l;++i) {
    if ( gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects1[k] = gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects1[i];
        ++k;
    }
}
gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "未命名場景");
}
}

}


};

gdjs._27161_38988_20171_38754Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._27161_38988_20171_38754Code.GDNewPanelSprite2Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GDNewPanelSprite2Objects2.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9538283_9522987_9536938_9525138_9525991_9526412Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9538283_9522987_9536938_9525138_9525991_9526412Objects2.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects2.length = 0;
gdjs._27161_38988_20171_38754Code.GDNewPanelSpriteObjects1.length = 0;
gdjs._27161_38988_20171_38754Code.GDNewPanelSpriteObjects2.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9536984_9521934Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9536984_9521934Objects2.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9524863_9525033_9522602Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9524863_9525033_9522602Objects2.length = 0;

gdjs._27161_38988_20171_38754Code.eventsList0(runtimeScene);
gdjs._27161_38988_20171_38754Code.GDNewPanelSprite2Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GDNewPanelSprite2Objects2.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9538283_9522987_9536938_9525138_9525991_9526412Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9538283_9522987_9536938_9525138_9525991_9526412Objects2.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9536938_9525138_9538283_9522987_9537749Objects2.length = 0;
gdjs._27161_38988_20171_38754Code.GDNewPanelSpriteObjects1.length = 0;
gdjs._27161_38988_20171_38754Code.GDNewPanelSpriteObjects2.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9536984_9521934Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9536984_9521934Objects2.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9524863_9525033_9522602Objects1.length = 0;
gdjs._27161_38988_20171_38754Code.GD_9524863_9525033_9522602Objects2.length = 0;


return;

}

gdjs['_27161_38988_20171_38754Code'] = gdjs._27161_38988_20171_38754Code;
