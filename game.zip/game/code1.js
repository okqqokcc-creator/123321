gdjs._26410_21629_21517_22580_26223Code = {};
gdjs._26410_21629_21517_22580_26223Code.localVariables = [];
gdjs._26410_21629_21517_22580_26223Code.idToCallbackMap = new Map();
gdjs._26410_21629_21517_22580_26223Code.forEachIndex2 = 0;

gdjs._26410_21629_21517_22580_26223Code.forEachObjects2 = [];

gdjs._26410_21629_21517_22580_26223Code.forEachTemporary2 = null;

gdjs._26410_21629_21517_22580_26223Code.forEachTotalCount2 = 0;

gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1= [];
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects2= [];
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects3= [];
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects4= [];
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects1= [];
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects2= [];
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects3= [];
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects4= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects1= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects2= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects3= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects4= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects1= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects2= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects3= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects4= [];
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects1= [];
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects2= [];
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects3= [];
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects4= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects1= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects2= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects3= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects4= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects1= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects2= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3= [];
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects4= [];


gdjs._26410_21629_21517_22580_26223Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite"), gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("_01"), gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1);
gdjs.copyArray(runtimeScene.getObjects("對話文本"), gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects1);
gdjs.copyArray(runtimeScene.getObjects("感應塊"), gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects1);
{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "New dialogue tree");
}
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects1.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects1.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects1.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects1[i].hide();
}
}
}

}


};gdjs._26410_21629_21517_22580_26223Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("選單"), gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects1.length;i<l;++i) {
    if ( gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects1[k] = gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects1[i];
        ++k;
    }
}
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "菜單場景");
}
}

}


};gdjs._26410_21629_21517_22580_26223Code.asyncCallback12539284 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs._26410_21629_21517_22580_26223Code.localVariables);
gdjs._26410_21629_21517_22580_26223Code.localVariables.length = 0;
}
gdjs._26410_21629_21517_22580_26223Code.idToCallbackMap.set(12539284, gdjs._26410_21629_21517_22580_26223Code.asyncCallback12539284);
gdjs._26410_21629_21517_22580_26223Code.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs._26410_21629_21517_22580_26223Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs._26410_21629_21517_22580_26223Code.asyncCallback12539284(runtimeScene, asyncObjectsList)), 12539284, asyncObjectsList);
}
}

}


};gdjs._26410_21629_21517_22580_26223Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.dialogueTree.goToNextDialogueLine();
}

{ //Subevents
gdjs._26410_21629_21517_22580_26223Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs._26410_21629_21517_22580_26223Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isDialogueLineType("text");
if (isConditionTrue_0) {

{ //Subevents
gdjs._26410_21629_21517_22580_26223Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs._26410_21629_21517_22580_26223Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("_01"), gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1.length;i<l;++i) {
    if ( gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1[k] = gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1[i];
        ++k;
    }
}
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1 */
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1[i].hide();
}
}
}

}


};gdjs._26410_21629_21517_22580_26223Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isRunning();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("對話文本"), gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects2);
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects2.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects2[i].getBehavior("Text").setText(gdjs.dialogueTree.getLineText());
}
}

{ //Subevents
gdjs._26410_21629_21517_22580_26223Code.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite"), gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("對話文本"), gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects1);
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects1.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects1.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects1[i].hide();
}
}

{ //Subevents
gdjs._26410_21629_21517_22580_26223Code.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs._26410_21629_21517_22580_26223Code.mapOfGDgdjs_9546_959526410_959521629_959521517_959522580_959526223Code_9546GD_95959524863_95959525033_95959522602Objects2Objects = Hashtable.newFrom({"感應塊": gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects2});
gdjs._26410_21629_21517_22580_26223Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite"), gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects3);
gdjs.copyArray(runtimeScene.getObjects("_01"), gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects3);
gdjs.copyArray(runtimeScene.getObjects("對話文本"), gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects3);
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects3.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects3.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects3[i].hide(false);
}
}
{gdjs.dialogueTree.startFrom("試用");
}
{for(var i = 0, len = gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects3.length ;i < len;++i) {
    gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects3[i].hide(false);
}
}
}

}


};gdjs._26410_21629_21517_22580_26223Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects2, gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3.length;i<l;++i) {
    if ( gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3[i].getX() == 1015 ) {
        isConditionTrue_0 = true;
        gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3[k] = gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3[i];
        ++k;
    }
}
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3.length;i<l;++i) {
    if ( gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3[i].getY() == 278 ) {
        isConditionTrue_0 = true;
        gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3[k] = gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3[i];
        ++k;
    }
}
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs._26410_21629_21517_22580_26223Code.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs._26410_21629_21517_22580_26223Code.eventsList9 = function(runtimeScene) {

{


gdjs._26410_21629_21517_22580_26223Code.eventsList0(runtimeScene);
}


{


gdjs._26410_21629_21517_22580_26223Code.eventsList1(runtimeScene);
}


{


gdjs._26410_21629_21517_22580_26223Code.eventsList6(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("感應塊"), gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects1);

for (gdjs._26410_21629_21517_22580_26223Code.forEachIndex2 = 0;gdjs._26410_21629_21517_22580_26223Code.forEachIndex2 < gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects1.length;++gdjs._26410_21629_21517_22580_26223Code.forEachIndex2) {
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects2.length = 0;


gdjs._26410_21629_21517_22580_26223Code.forEachTemporary2 = gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects1[gdjs._26410_21629_21517_22580_26223Code.forEachIndex2];
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects2.push(gdjs._26410_21629_21517_22580_26223Code.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs._26410_21629_21517_22580_26223Code.mapOfGDgdjs_9546_959526410_959521629_959521517_959522580_959526223Code_9546GD_95959524863_95959525033_95959522602Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents: 
gdjs._26410_21629_21517_22580_26223Code.eventsList8(runtimeScene);} //Subevents end.
}
}

}


};

gdjs._26410_21629_21517_22580_26223Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects4.length = 0;

gdjs._26410_21629_21517_22580_26223Code.eventsList9(runtimeScene);
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959501Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_959502Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9523565_9535441_9525991_9526412Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934_9525991_9526412Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GDNewPanelSpriteObjects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9536984_9521934Objects4.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects1.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects2.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects3.length = 0;
gdjs._26410_21629_21517_22580_26223Code.GD_9524863_9525033_9522602Objects4.length = 0;


return;

}

gdjs['_26410_21629_21517_22580_26223Code'] = gdjs._26410_21629_21517_22580_26223Code;
