gdjs._33756_21934_22580_26223Code = {};
gdjs._33756_21934_22580_26223Code.localVariables = [];
gdjs._33756_21934_22580_26223Code.idToCallbackMap = new Map();
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects1= [];
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects2= [];
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988_9525991_9526412Objects1= [];
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988_9525991_9526412Objects2= [];
gdjs._33756_21934_22580_26223Code.GD_9532380_9532396_9536938_9525138_9525991_9526412Objects1= [];
gdjs._33756_21934_22580_26223Code.GD_9532380_9532396_9536938_9525138_9525991_9526412Objects2= [];
gdjs._33756_21934_22580_26223Code.GDNewPanelSpriteObjects1= [];
gdjs._33756_21934_22580_26223Code.GDNewPanelSpriteObjects2= [];
gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects1= [];
gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects2= [];
gdjs._33756_21934_22580_26223Code.GD_9524863_9525033_9522602Objects1= [];
gdjs._33756_21934_22580_26223Code.GD_9524863_9525033_9522602Objects2= [];


gdjs._33756_21934_22580_26223Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("選單"), gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects1.length;i<l;++i) {
    if ( gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects1[k] = gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects1[i];
        ++k;
    }
}
gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "未命名場景", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("返回標題"), gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects1.length;i<l;++i) {
    if ( gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects1[k] = gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects1[i];
        ++k;
    }
}
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 100, 1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "標題介面", false);
}
}

}


};

gdjs._33756_21934_22580_26223Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects2.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988_9525991_9526412Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988_9525991_9526412Objects2.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9532380_9532396_9536938_9525138_9525991_9526412Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9532380_9532396_9536938_9525138_9525991_9526412Objects2.length = 0;
gdjs._33756_21934_22580_26223Code.GDNewPanelSpriteObjects1.length = 0;
gdjs._33756_21934_22580_26223Code.GDNewPanelSpriteObjects2.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects2.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9524863_9525033_9522602Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9524863_9525033_9522602Objects2.length = 0;

gdjs._33756_21934_22580_26223Code.eventsList0(runtimeScene);
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988Objects2.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988_9525991_9526412Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536820_9522238_9527161_9538988_9525991_9526412Objects2.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9532380_9532396_9536938_9525138_9525991_9526412Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9532380_9532396_9536938_9525138_9525991_9526412Objects2.length = 0;
gdjs._33756_21934_22580_26223Code.GDNewPanelSpriteObjects1.length = 0;
gdjs._33756_21934_22580_26223Code.GDNewPanelSpriteObjects2.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9536984_9521934Objects2.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9524863_9525033_9522602Objects1.length = 0;
gdjs._33756_21934_22580_26223Code.GD_9524863_9525033_9522602Objects2.length = 0;


return;

}

gdjs['_33756_21934_22580_26223Code'] = gdjs._33756_21934_22580_26223Code;
